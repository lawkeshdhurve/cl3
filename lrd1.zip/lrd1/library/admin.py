from django.contrib import admin
from .models import Books  # Correct import

class BooksAdmin(admin.ModelAdmin):  # Capitalized class name
    list_display = ('user', 'book_name', 'author')  # Correct list format (not nested)

    exclude = ['user']

    def save_model(self, request, obj, form, change):
        obj.user = request.user
        obj.save()

admin.site.register(Books, BooksAdmin)  # Corrected model name
